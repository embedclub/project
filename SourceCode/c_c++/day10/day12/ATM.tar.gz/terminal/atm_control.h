#ifndef __ATM_CONTROL_H__
#define __ATM_CONTROL_H__

void Create_Bill(int msgid_w,int msgid_r);

void Destroy_Bill(int msgid_w,int msgid_r);

void Save_Money(int msgid_w,int msgid_r);

void Take_Money(int msgid_w,int msgid_r);

void Query_Money(int msgid_w,int msgid_r);

void Transfer_Money(int msgid_w,int msgid_r);


#endif
