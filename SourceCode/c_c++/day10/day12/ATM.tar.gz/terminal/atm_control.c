#include"atm.h"

void Login(struct Person *user)
{
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入要登陆的账户(7478~2147483647):");
	}while(scanf("%d",&user->BillID)==0||user->BillID>2047483647||user->BillID<7478);
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入密码(6位):");
	}while(scanf("%d",&user->BillPasswd)==0||user->BillPasswd>999999||user->BillPasswd<100000);

}

void Create_Bill(int msgid_w,int msgid_r)
{
	struct message MSG={0};
	int flag=1;
	char ch = 'Y';
	int passwd_tmp;
	Window_Create();
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入正确的选项:");
	}while(scanf("%d",&flag)==0||((flag>2)||(flag<=0)));
	if(flag == 2)
	{
		return ;
	}
	do
	{
		do
		{
			flag = 0;
			system("clear");
			printf("请输入账户姓名:");
			scanf("%*[^\n]");
			scanf("%*c");
			fgets(MSG.person.PersonName,16,stdin);
			if((strlen(MSG.person.PersonName)==15)&&(MSG.person.PersonName[14]!='\n'))
			{
				scanf("%*[^\n]");
				scanf("%*c");
			}
			char *p = MSG.person.PersonName;
			while(*p!= '\0')
			{
				if(*p>='0'&&*p<='9')
				{
					flag = 1;
					printf("姓名中不能包含数字！\n");
					sleep(1);
					break;
				}
				p++;
			}
		}while(flag);
		do
		{
			printf("请设置密码(6位):");
			scanf("%*[^\n]");
			scanf("%*c");
		}while(scanf("%d",&MSG.person.BillPasswd)==0||MSG.person.BillPasswd>999999||MSG.person.BillPasswd<100000);
		do
		{
			scanf("%*[^\n]");
			scanf("%*c");
			printf("请再次输入密码确认(6位):");
		}while(scanf("%d",&passwd_tmp)==0|passwd_tmp>999999||passwd_tmp<100000);
		if(passwd_tmp == MSG.person.BillPasswd)
		{
			MSG.mtype = 1;
			Write_Msg(msgid_w,&MSG);
			Read_Msg(msgid_r,&MSG,1);//读取信息,不成功不返回
			if(strcmp(MSG.person.optmsg,"OK!")==0)//判断结果信息是否成功
			{
				printf("账户创建成功,ID为:%d\n",MSG.person.BillID);
			}
			else
			{
				printf("error:%s\n",MSG.person.optmsg);
			}
		}
		else
		{
			printf("两次密码输入不同，请重新注册\n");
			sleep(1);
			ch = 'Y';
			continue;
		}
		scanf("%*[^\n]");
		scanf("%*c");
		printf("继续请输入Y,其他任意键退出\n");
		ch = getchar();
	}while(ch=='Y');
}

void Destroy_Bill(int msgid_w,int msgid_r)
{
	struct message MSG={0};
	int flag =1;
	char ch = 'Y';
	Window_Destroy();
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入正确的选项:");
	}while(scanf("%d",&flag)==0||((flag>2)||(flag<=0)));
	if(flag == 2)
	{
		return ;
	}
	do
	{
		system("clear");
		Login(&(MSG.person));
		int temp =0,temp1 =0;
		do
		{
			scanf("%*[^\n]");
			scanf("%*c");
			printf("请确认是否销毁该账户,请输入下列数字确认：");
			temp = rand()%10000;
			printf("%d\n",temp);
		}while(scanf("%d",&temp1)==0);
		if(temp == temp1)
		{
			MSG.mtype = 2;
			Write_Msg(msgid_w,&MSG);
			Read_Msg(msgid_r,&MSG,2);//读取信息,不成功不返回
			if(strcmp(MSG.person.optmsg,"OK!")==0)//判断结果信息是否成功
			{
				printf("删除账户%d成功!\n",MSG.person.BillID);
			}
			else
			{
				printf("error:%s\n",MSG.person.optmsg);
			}
		}
		else
		{
			printf("验证码不正确!\n");
			sleep(1);
			ch = 'Y';
			continue;
		}
		scanf("%*[^\n]");
		scanf("%*c");
		printf("继续请输入Y,其他任意键退出\n");
		ch = getchar();
	}while(ch=='Y');
}


void Save_Money(int msgid_w,int msgid_r)
{
	struct message MSG={0};
	int flag=0;
	char ch = 'Y';
	Window_Save();
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入正确的选项:");
	}while(scanf("%d",&flag)==0||((flag>2)||(flag<=0))); 
	if(flag == 2)
	{
		return ;
	}
	do
	{
	system("clear");
	Login(&(MSG.person));	
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入要存入的金额:");
	}while(scanf("%f",&MSG.person.money)==0);
	MSG.mtype = 3;
	Write_Msg(msgid_w,&MSG);
	Read_Msg(msgid_r,&MSG,3);//读取信息,不成功不返回
	if(strcmp(MSG.person.optmsg,"OK!")==0)//判断结果信息是否成功
	{
		printf("存款成功!\n");
	}
	else
	{
		printf("error:%s\n",MSG.person.optmsg);
	}
	scanf("%*[^\n]");
	scanf("%*c");
	printf("继续请输入Y,其他任意键退出\n");
	ch = getchar();
	}while(ch =='Y');
}

void Take_Money(int msgid_w,int msgid_r)
{
        struct message MSG ={0};
	int flag = 1;
	char ch='Y';
        Window_Take();
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入正确的选项:");
	}while(scanf("%d",&flag)==0||((flag>2)||(flag<=0)));
	if(flag == 2)
	{
		return ;
	}
	do
	{
		system("clear");
		Login(&(MSG.person));
		do
		{
			scanf("%*[^\n]");
			scanf("%*c");
			printf("请输入要取出的金额:");
		}while(scanf("%f",&MSG.person.money)==0);
		MSG.mtype = 4;
		Write_Msg(msgid_w,&MSG);
		Read_Msg(msgid_r,&MSG,4);//读取信息,不成功不返回
		if(strcmp(MSG.person.optmsg,"OK!")==0)//判断结果信息是否成功
		{
			printf("取款成功!\n");
		}
		else
		{
			printf("error:%s\n",MSG.person.optmsg);
		}
		scanf("%*[^\n]");
		scanf("%*c");
		printf("继续请输入Y,其他任意键退出\n");
		ch = getchar();
	}while(ch=='Y');
}

void Query_Money(int msgid_w,int msgid_r)
{
	struct message MSG={0};
	int flag = 0;
	char ch='Y';
	Window_Query();
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入正确的选项:");
	}while(scanf("%d",&flag)==0||((flag>2)||(flag<=0)));
	if(flag == 2)
	{
		return ;
	}
	do
	{
	system("clear");
	Login(&(MSG.person));
	MSG.mtype = 5;
	Write_Msg(msgid_w,&MSG);
	Read_Msg(msgid_r,&MSG,5);//读取信息,不成功不返回
	if(strcmp(MSG.person.optmsg,"OK!")==0)//判断结果信息是否成功
	{
		printf("账户余额为:%f\n",MSG.person.money);
	}
	else
	{
		printf("error:%s\n",MSG.person.optmsg);
	}
	scanf("%*[^\n]");
	scanf("%*c");
	printf("继续请输入Y,其他任意键退出\n");
	ch = getchar();
	}while(ch=='Y');
	
}

void Transfer_Money(int msgid_w,int msgid_r)
{
	struct message MSG = {0};
	struct message MSG1 = {0};
	int flag = 0;
	char ch = 'Y';
	Window_Transfer();
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入正确的选项:");
	}while(scanf("%d",&flag)==0||((flag>2)||(flag<=0)));
	if(flag == 2)
	{
		return ;
	}
	do
	{
	system("clear");
	Login(&(MSG.person));
	MSG.mtype = 6;
	Write_Msg(msgid_w,&MSG);
	Read_Msg(msgid_r,&MSG,6);//读取信息,不成功不返回
	if(strcmp(MSG.person.optmsg,"OK!")==0)//判断结果信息是否成功
	{
		printf("登陆成功!\n");
	}
	else
	{
		printf("error:%s\n",MSG.person.optmsg);
		printf("继续请输入Y,其他任意键退出\n");
		ch = getchar();
		continue;
	}
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入要转帐的账户ID:");
	}while(scanf("%d",&MSG1.person.BillID)==0);
	do
	{
		scanf("%*[^\n]");
		scanf("%*c");
		printf("请输入要转账的金额:");
	}while(scanf("%f",&MSG1.person.money)==0);
	MSG1.mtype = 7;
	Write_Msg(msgid_w,&MSG1);
	Read_Msg(msgid_r,&MSG1,7);//读取信息,不成功不返回
	if(strcmp(MSG1.person.optmsg,"OK!")==0)//判断结果信息是否成功
	{
		printf("转账成功!\n");
	}
	else
	{
		printf("error:%s\n",MSG1.person.optmsg);
	}
	scanf("%*[^\n]");
	scanf("%*c");
	printf("继续请输入Y,其他任意键退出\n");
	ch = getchar();
	}while(ch=='Y');	
}
