#include"atm.h"

void Window_Main()
{
        system("clear");
        printf("/****************ATM系统主菜单界面****************/\n");
        printf("/   1                   开户                      /\n");
        printf("/   2                   销户                      /\n");
        printf("/   3                   存钱                      /\n");
        printf("/   4                   取钱                      /\n");
        printf("/   5                   查询                      /\n");
        printf("/   6                   转账                      /\n");
        printf("/*************************************************/\n");
}

void Window_Create()
{
	system("clear");
        printf("/***************ATM系统创建账户界面***************/\n");
        printf("/   1                   开户                      /\n");
        printf("/   2                  上一步                     /\n");
        printf("/*************************************************/\n");
}

void Window_Destroy()
{
	system("clear");
        printf("/***************ATM系统销毁账户界面***************/\n");
        printf("/   1                   销户                      /\n");
        printf("/   2                  上一步                     /\n");
        printf("/*************************************************/\n");
}

void Window_Save()
{
	system("clear");
        printf("/*****************ATM系统存款界面*****************/\n");
        printf("/   1                   存款                      /\n");
        printf("/   2                  上一步                     /\n");
        printf("/*************************************************/\n");
}

void Window_Take()
{
	system("clear");
        printf("/*****************ATM系统取款界面*****************/\n");
        printf("/   1                   取款                      /\n");
        printf("/   2                  上一步                     /\n");
        printf("/*************************************************/\n");
}

void Window_Query()
{
	system("clear");
        printf("/***************ATM系统账户转账界面***************/\n");
        printf("/   1                   查询                      /\n");
        printf("/   2                  上一步                     /\n");
        printf("/*************************************************/\n");
}

void Window_Transfer()
{
	system("clear");
        printf("/***************ATM系统账户转账界面***************/\n");
        printf("/   1                   转账                      /\n");
        printf("/   2                  上一步                     /\n");
        printf("/*************************************************/\n");
}

