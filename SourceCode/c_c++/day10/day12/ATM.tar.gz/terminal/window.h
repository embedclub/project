#ifndef __WINDOW_H__
#define __WINDOW_H__

void Window_Main();

void Window_Create();

void Window_Destroy();

void Window_Save();

void Window_Take();

void Window_Query();

void Window_Transfer();
#endif
