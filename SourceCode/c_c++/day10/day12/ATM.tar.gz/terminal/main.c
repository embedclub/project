#include"atm.h"


void child_process(int choice,int msgid_w,int msgid_r)
{
	switch(choice)
	{
		case 1: Create_Bill(msgid_w,msgid_r) ;break;
		case 2: Destroy_Bill(msgid_w,msgid_r);break;
		case 3: Save_Money(msgid_w,msgid_r);break;
		case 4: Take_Money(msgid_w,msgid_r);break;
		case 5: Query_Money(msgid_w,msgid_r);break;
		case 6: Transfer_Money(msgid_w,msgid_r);break;
		default :break;
	}
}

int main()
{
	srand(time(0));
	key_t key_w = ftok("../",200);
	key_t key_r = ftok("../",201);

	int msgid_w = msgget(key_w,0);
	int msgid_r = msgget(key_r,0);
	
	if(msgid_r == -1)
	{
		perror("msgget_r failed!\n");
		return -1;
	}
	if(msgid_w == -1)
	{
		perror("msgget_w failed!\n");
		return -1;
	}
	while(1)
	{
		int choice =0;
		Window_Main();
		printf("请输入选择:");
		while(scanf("%d",&choice)==0)
		{
			scanf("%*[^\n]");
			scanf("%*c");
			printf("请输入选择:\n");
		}//避免输入字符无法读取
		child_process(choice,msgid_w,msgid_r);
	}
	return 0;
}
