#ifndef __MSG_CONTROL_H__
#define __MSG_CONTROL_H__
#include"atm.h"

void Read_Msg(int msgid,void *buf,int msgtyp);//读取消息队列信息

void Write_Msg(int msgid,void *buf);//发送消息


#endif
