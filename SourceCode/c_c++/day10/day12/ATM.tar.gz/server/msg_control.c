#include"atm.h"

void Read_Msg(int msgid,void *buf,int msgtyp)//读取消息队列信息
{
	int res = msgrcv(msgid,buf,sizeof(struct Person),msgtyp,0);//发送一个消息包
	if(res == -1)//接收失败判断
	{
		perror("msgrcv failed");
		exit(-1);
	}
}

void Write_Msg(int msgid,void *buf)//发送消息
{
	int res = msgsnd(msgid,buf,sizeof(struct Person),0);//发送消息包
	if(res == -1)//发送失败判断
	{
		perror("msgsnd failed");
		exit(-1);
	}
}



