#ifndef __ATM_CONTROL_H__
#define __ATM_CONTROL_H__
#include"atm.h"
typedef struct Person PER;

int Create_Bill(PER *user);

int Destroy_Bill(PER *user);

int Save_Money(PER *user);

int Take_Money(PER *user);

int Query_Money(PER *user);

int Transfer_Money(PER *own ,PER *user);


#endif
