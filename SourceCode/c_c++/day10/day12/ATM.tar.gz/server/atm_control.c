#include"atm.h"


int Bill_Write(char *dir,PER *user)
{	
	char path[256]={0};
	sprintf(path,"%s%d",dir,user->BillID);
	printf("%s\n",path);
	int fd = open(path,O_WRONLY|O_CREAT,0666);
	if(fd == -1)
	{
		if(errno == 2)
		{
			mkdir(dir,0777);//单独创建一个目录来保存ID
			fd = open(path,O_WRONLY|O_CREAT,0666);
			if(fd == -1)
			{
				strcpy(user->optmsg,strerror(errno));
				return -1;
			}
		}
		else
		{
			strcpy(user->optmsg,strerror(errno));
			return -1;
		}
	}
	lseek(fd,0,SEEK_SET);
	if(write(fd,user,68)==68)
	{
	//	printf("write OK!");
		close(fd);
		return 0;
	}
	else
	{
		strcpy(user->optmsg,"write BillID failed!");
		return -1;
	}
}

int Bill_Read(char *dir ,PER *user)
{
	char path[256]={0};
	sprintf(path,"%s%d",dir,user->BillID);
	printf("%s\n",path);
	int fd = open(path,O_RDONLY);
	if(fd == -1)
	{
		strcpy(user->optmsg,strerror(errno));
	//	printf("%s\n",user->optmsg);
		return -1;
	}
	lseek(fd,0,SEEK_SET);
	if(read(fd,user,68)==68)
	{
	//	printf("Bill read!\n");
	//	printf("%s",user->PersonName);
	//	printf("%d\n",user->BillID);
	//	printf("%d\n",user->BillPasswd);
	//	printf("%f\n",user->money);
	//	printf("%s\n",user->optmsg);
		close(fd);
		return 0;
	}
	else
	{
		printf("read error");
		strcpy(user->optmsg,"read BillID failed!");
		return -1;
	}
}


int Bill_Login(PER *user)
{
	PER own={0};
	own.BillID = user->BillID;
	if(Bill_Read("./bill/",&own)==-1)
	{
		strcpy(user->optmsg,own.optmsg);
		return -1;	
	}
	if(own.BillPasswd == user->BillPasswd)
	{
		strcpy(user->PersonName,own.PersonName);
		user->money = own.money;
		strcpy(user->optmsg,"OK!");
		return 0;
	}
	else
	{
		strcpy(user->optmsg,"passwd error");
		return -1;
	}
}

int Create_Bill(PER *user)
{
//这里可以简化一下！！！
	int fd = open("BillID.dat",O_RDWR|O_CREAT,0666);
	if(fd == -1)
	{
		strcpy(user->optmsg,"BillID.dat open failed,");
		strcat(user->optmsg,strerror(errno));
		return ;
	}
	lseek(fd,0,SEEK_SET);
	if(read(fd,&(user->BillID),4)==0)
	{
		user->BillID = 7478;
	}
	else
	{
		user->BillID += 1;
	}
	lseek(fd,0,SEEK_SET);
	if(write(fd,&user->BillID,4)==4)//保存ID至BillID.dat
	{
		close(fd);//关闭BillID.dat
		/*将信息写入ID文件中*/
		if(Bill_Write("./bill/",user)==-1)
		{
			return -1;
		}
	}
	else
	{
		strcpy(user->optmsg,"write BillID failed");
		return -1;//失败退出
	}
	strcpy(user->optmsg,"OK!");
	return 0;
}

int Destroy_Bill(PER *user)
{
	if(Bill_Login(user) == -1)
	{
		return -1;
	}
	char path[256]={0};
	sprintf(path,"%s%d","./bill/",user->BillID);
	remove(path);
	strcpy(user->optmsg,"OK!");
	return 0;
}


int Save_Money(PER *user)
{
	PER own={0};
	own.BillID = user->BillID;
	own.BillPasswd = user->BillPasswd;
        if(Bill_Login(&own)==-1)
	{
		strcpy(user->optmsg,own.optmsg);
		return -1;
	}
	user->money += own.money;
	own.money = user->money;
	strcpy(user->PersonName,own.PersonName);
	if(Bill_Write("./bill/",&own)==-1)
	{
		strcpy(user->optmsg,own.optmsg);
		return -1;
	}
	strcpy(user->optmsg,"OK!");
	return 0;
}

int Take_Money(PER *user)
{
	PER own={0};
	own.BillID = user->BillID;//将穿过来的ID 和密码保存，用作登录
	own.BillPasswd = user->BillPasswd;
        if(Bill_Login(&own)==-1)//登录获取账户信息，保存在own中
	{
		strcpy(user->optmsg,own.optmsg);
		return -1;
	}
	if(own.money<user->money)//判断金额是否足够
	{
		strcpy(user->optmsg,"money too less");
		return -1;
	}
	user->money = own.money - user->money;
	strcpy(user->PersonName,own.PersonName);
	if(Bill_Write("./bill/",user)==-1)
	{
		strcpy(user->optmsg,own.optmsg);
		return -1;
	}
	strcpy(user->optmsg,"OK!");
	return 0;
}

int Query_Money(PER *user)
{
	PER own={0};
	if(Bill_Login(user)==-1)
	{
		return -1;
	}
	strcpy(user->optmsg,"OK!");
	return 0;
}

int Transfer_Money(PER *own,PER *user)
{
	if(user->money - own->money>=0)//转账金额不足则退出
	{
		strcpy(user->optmsg,"money to less");
		return -1;
	}
	float money = user->money;
	if(Bill_Read("./bill/",user)==-1)//判断要转帐的账户是否存在，并读取信息
	{
		return -1;
	}
	user->money +=money; 
	if(Bill_Write("./bill/",user)==-1)
	{
		return -1;
	}
	own->money -= money;
	if(Bill_Write("./bill/",own)==-1)
	{
		return -1;
	}
	strcpy(user->optmsg,"OK!");
	return 0;
}
