#ifndef __ATM_H__
#define __ATM_H__
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<time.h>
#include<errno.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include"atm_control.h"
#include"msg_control.h"

struct Person
{
//	pid_t pid;//记录是哪个终端发送
	int BillID;//账户ID
	char PersonName[16];//户主姓名
	int BillPasswd;//账户密码
	float money;//金额
	char optmsg[40];//要返回的操作结果信息
};


struct message
{
	long mtype;//记录消息类型
	struct Person person;//要传送的消息内容
};




#endif


