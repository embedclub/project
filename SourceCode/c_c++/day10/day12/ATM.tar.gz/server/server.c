#include"atm.h"

int msgid_w,msgid_r;

void func(int signum)
{
	msgctl(msgid_w,IPC_RMID,NULL);
	msgctl(msgid_r,IPC_RMID,NULL);
	exit(0);
}

void Print(struct message *MSG)
{
	printf("%s\n",MSG->person.PersonName);
	printf("%d\n",MSG->person.BillID);
	printf("%d\n",MSG->person.BillPasswd);
	printf("%f\n",MSG->person.money);
	printf("%s\n",MSG->person.optmsg);
}

int main()
{
	key_t key_r = ftok("../",200);
	key_t key_w = ftok("../",201);
	
	msgid_r = msgget(key_r,IPC_CREAT|IPC_EXCL|0666);
	msgid_w = msgget(key_w,IPC_CREAT|IPC_EXCL|0666);

	if(msgid_r == -1)
	{
		perror("msgget_r failed!\n");
		return -1;
	}
	if(msgid_w == -1)
	{
		perror("msgget_w failed!\n");
		return -1;
	}
	signal(SIGINT,func);
	pid_t pid = fork();
	if(pid == 0)
	{
		pid = fork();
		if(pid ==0)
		{
			pid = fork();
			if(pid == 0)
			{	
				while(1)
				{
				struct message MSG={0};
				Read_Msg(msgid_r,&MSG,1);
				if(MSG.mtype!=0)
				{
					Create_Bill(&(MSG.person));
					Print(&MSG);
					Write_Msg(msgid_w,&MSG);
					printf("1\n");
				}
				}
			}
			else
			{
				while(1)
				{
				struct message MSG={0};
				Read_Msg(msgid_r,&MSG,2);
				if(MSG.mtype!=0)
				{
					Destroy_Bill(&(MSG.person));
					Print(&MSG);
					Write_Msg(msgid_w,&MSG);
					printf("2\n");
				}
				}
			}
		}
		else
		{
			pid = fork();
			if(pid == 0)
			{
				while(1)
				{
				struct message MSG={0};
				Read_Msg(msgid_r,&MSG,3);
				if(MSG.mtype!=0)
				{
					Save_Money(&(MSG.person));
					Print(&MSG);
					Write_Msg(msgid_w,&MSG);
					printf("3\n");
				}
				}
			}
			else
			{
				while(1)
				{
				struct message MSG={0};
				Read_Msg(msgid_r,&MSG,4);
				if(MSG.mtype!=0)
				{
					Take_Money(&(MSG.person));
					Print(&MSG);
					Write_Msg(msgid_w,&MSG);
					printf("4\n");
				}
				}
			}
		}
	}
	else
	{
		pid = fork();
		if(pid ==0)
		{
			while(1)
			{
			struct message MSG={0};
			Read_Msg(msgid_r,&MSG,5);
			if(MSG.mtype!=0)
			{
			Query_Money(&(MSG.person));
			Print(&MSG);
			Write_Msg(msgid_w,&MSG);
			printf("5\n");
			}
			}
		}
		else
		{
			while(1)
			{
			struct message MSG={0};
			struct message MSG1={0};
			Read_Msg(msgid_r,&MSG,6);//接收户主信息
			if(MSG.mtype!=0)
			{
				if(Bill_Login(&MSG.person)==-1)
				{	
					Print(&MSG);
					Write_Msg(msgid_w,&MSG);
					continue;
				}
				Print(&MSG);
				Write_Msg(msgid_w,&MSG);
				Read_Msg(msgid_r,&MSG1,7);//转账对象信息
				Transfer_Money(&(MSG.person),&(MSG1.person));
				Print(&MSG);
				Write_Msg(msgid_w,&MSG1);
				printf("6\n");
			}
			}
		}
	}
	
	return 0;
}
